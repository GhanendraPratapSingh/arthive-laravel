<?php

namespace App\Http\Controllers;

use App\Models\Bookedtimeslot;
use App\Models\Booking;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Auth\Events\Validated;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Razorpay\Api\Api;
use Throwable;

class BookingController extends Controller
{
    

    public function getKidsCalender(Request $request)  {
        try {
            $now = Carbon::now();
            $type = $request->type ?? 'next';
            $month = $request->month ?? (clone $now)->format('m');
            $year = $request->year ?? (clone $now)->format('Y');

            $selectedDate = ($now)->year($year)->month($month)->day(1);
            $previousDate =  (clone $selectedDate)->subMonth();
            $nextDate =  (clone $selectedDate)->addMonth();
            
            
            $currentDate = (clone $now);
        

            

           
            $nextMonth =  $month+1;
            // dd($currentMonth->daysInMonth);

            $data = compact('month','year','selectedDate','previousDate','nextDate');
            // dd($data);
            return view('calender',$data);
        } catch (Throwable $th) {
            dd($th->getMessage());
        }
    }

    public function kidsSlotBookingPage(Request $request,$date){
    
        return view('book',compact('date'));
    }

    public function saveKidsSlotData(Request $request){

        $date = $request->date;
        $name = $request->name;
        $mobile = $request->mobile;
        $timeslot = $request->timeslot;
        $quantity = $request->quantity;
        $email = $request->email;
        $validation = $request->validate([
            'name' => ['required'],
            'mobile' => ['required'],
            'timeslot' => ['required'],
            'quantity' =>['required'],
            'email' => ['required'],
        ]);
        $bookedSlotsQuantity = Booking::where(['date' => $date,'timeslot'=>$timeslot])->sum('quantity');
       
        if($quantity>10){
            Session::flash('bookingError', "Only 10 slots can be booked at a time");
            return Redirect::back();
        }else if($bookedSlotsQuantity>10){
            Session::flash("bookingError","The slot is now full. You can book some other slot or contact us with your query. Thank You!");
            return Redirect::back();
        }else if($bookedSlotsQuantity+$quantity>10){
            $totalSlots = 10;
            Session::flash("bookingError","Only " . ($totalSlots - $bookedSlotsQuantity) . "  slot  available in this time slot !! ");
            return Redirect::back();
        }else {
            // if($bookedSlotsQuantity+$quantity>=10){
                $createSlot = Bookedtimeslot::create([
                    'date'=>$request->date,
                    'timeslot' => $request->timeslot
                ]);
                $bookingData = [
                    'date' => $date,
                    'timeslot' => $timeslot,
                    'name' => $name,
                    'mobile' => $mobile,
                    'email' => $email,
                    'quantity' => $quantity,
                    'payment_status' => 'Not paid',
                ];
                $createBooking = Booking::create($bookingData);
                if($createBooking){
                    $bookingData['amount'] = 500*$quantity;
                    $bookingData['slot'] ='yes'; 
                    session("amount", 500 * $quantity);
                    session("slot", "yes");
                    session("name", $name);
                    session("email", $email);
                    session("timeslot", $timeslot);
                    session("quantity", $quantity);
                    session("date", $date);
                    return view('payment-check',$bookingData);                
                }else{
                    Session::flash('bookingError', "Something went wrong! Please try after sometime");
                    return Redirect::back();
                }
            // }else{

            // }
        }
    }

    public function dKidsPaymentShow(Request $request){
        $price = $request->price ?? 0;
        $type = $request->type ?? 'kids';
        if($price<=0){
            return redirect()->back();
        }
        return view('payment.information',compact('price','type'));
    }
    public function dKidsInitiatePayment(Request $request){
        $price = ($request->price ?? 0)*100;

        $razorpaySecretId = config('globals.razorpay_secret_id');
        $razorpaySecretKey = config('globals.razorpay_secret_key');
        $api = new Api($razorpaySecretId, $razorpaySecretKey);

        $dateArray = [
            'receipt' =>  'order_receipt_' .uniqid(), 
            'amount' => $price, 
            'currency' => 'INR', 
            'notes'=> array('Section'=> 'kids')
        ];
        $createUser = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'user_type' => $request->user_type ?? 'kids_user',
        ]);
        $createOrder = $api->order->create($dateArray);
        
        $dateArray['order_id'] = $createOrder->id;
        $dateArray['apiKey'] = $razorpaySecretId;
        $dateArray['receipt'] =  $createOrder->receipt;
        $dateArray = [
            'amount' => $price,
            'order_id' => $createOrder->id,
            'apiKey' => $razorpaySecretId,
            'receipt' => $createOrder->receipt,
            'name' => $request->name,
            'email' => $request->email,
            'mobile' => $request->mobile,
            'user_type' => $request->user_type ?? 'kids_user',
        ];

        
        
        if($price<=0){
            return redirect()->back();
        }

        return view('payment.payment',$dateArray);
    }
    
    public function dKidsConnfirmPayment(Request $request){
            try{
                print_r($request->all());
                $razorpay_payment_id = $request->input('razorpay_payment_id');
                $razorpay_order_id = $request->input('razorpay_order_id');
                $razorpay_signature = $request->input('razorpay_signature');
                $order_id = $request->input('tracking_number');
                $razorpaySecretId = config('globals.razorpay_secret_id');
                $razorpaySecretKey = config('globals.razorpay_secret_key');
                $generated_signature = hash_hmac('sha256', $razorpay_order_id . "|" . $razorpay_payment_id, $razorpaySecretKey);
                $is_payment_success  = false;
                if ($generated_signature == $razorpay_signature) {
                    $is_payment_success =true;
                    return view('payment.thank-you');
                }
                else{
                    dd("something went wrong");
                }

            }catch(Throwable $e){
                dd($e->getMessage());
            }
    }
    
}

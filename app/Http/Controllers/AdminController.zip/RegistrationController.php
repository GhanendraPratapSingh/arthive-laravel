<?php

namespace App\Http\Controllers;

use App\Models\ContactUs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

class RegistrationController extends Controller
{
    
    public function classRegistration(Request $request){
        $validation = $request->validate([
            'yourname' => ['required'],
            'age' => ['required'],
            'mobile' => ['required'],
            'email' => ['required'],
            'price' => ['required'],
        ]);
    }


    public function saveContactUs(Request $request){
        $validation = $request->validate([
            'fname' => ['required'],
            'lname' => ['required'],
            'mob' => ['required'],
            'msg' => ['required'],
        ]);

        $data =[
            'first_name' => $request->fname,
            'last_name' => $request->lname,
            'mobile' => $request->mob,
            'message' =>$request->msg,
        ];
        $isContacted = ContactUs::create($data);
        if(false){
            // Session::flash('contactUsSuccess', "Thanks For Registering");
            toastr()->success('Thanks For Registering');
            return redirect()->back();
            // return redirect()->back()->with('alert','Thanks For Registering');
            
        }
        // Session::flash('contactUsError', "Something went wrong!");
        toastr()->error('Something went wrong!');
        return redirect()->back();
        // return redirect()->back()->with('alert','Something went wrong!');
        // return Redirect::back();
    }
}

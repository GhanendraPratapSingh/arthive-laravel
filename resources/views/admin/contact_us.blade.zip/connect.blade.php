<?php
//  $conn  = mysqli_connect("localhost","thearthive_TheArtHiveUser","ErqS[ZRNi}7+","thearthive_thearthive") or die("DB Connection failed"); 
$conn  = mysqli_connect("localhost","root","","thearthive") or die("DB Connection failed"); 
 
 
 ?>
